﻿VOTING SYSTEM![ref1]![ref2]![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.003.png)![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.004.png)![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.005.jpeg)

VOTING SYSTEM![ref1]![ref2]![ref3]

MY DEATAILS:- ![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.007.jpeg)
**


`  `**[lakshmiprasannakumar026@gmail.com**](mailto:lakshmiprasannakumar026@gmail.com)![ref4]**
**


`    `**![ref5]**
**

**


-:PROJECT TOPIC: -![ref1]![ref2]![ref3]

VOTING SYSTEM 





`              `![ref4]



`            `![ref5]





**AGENDA :-![ref1]![ref2]![ref3]**
**

**

**

**


`           `**![ref4]**
**


`           `**![ref5]**
**

**

**


-:PROJECT OVERVIEW :-![ref1]![ref2]![ref5]![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.010.jpeg)![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.011.jpeg)![ref4]![ref3]

-:EXISTING SYSTEM:-![ref1]![ref2]![ref3]

`      `**![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.012.jpeg)**
**

**

**

**


`    `**![ref4]**
**


`  `**![ref5]**
**

**

**


**DISADVANTAGES OF EXISTING SYSTEM:-![ref1]![ref2]![ref3]**
**

**

**

**

**


![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.013.png) ![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.014.png)

***PROPOSED SYSTEM:![ref1]![ref2]![ref3]***

`      `**![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.015.jpeg)**
**

**

**

**

**


`       `**![ref4]**
**


`       `**![ref5]![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.016.png)**

ADVANTAGES OF PROPOSED SYSTEM:![ref1]![ref2]![ref3]
**

**

**

**

**


`          `**![ref4]**
**


`        `**![ref5]**
**


![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.017.png)![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.018.jpeg)

MODULES:![ref1]![ref2]![ref3]

`  `**![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.019.png)**
**

**

**


`   `**![ref4]**
**


`  `**![ref5]![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.020.png)**
**


-:MODELING:-![ref1]![ref2]![ref5]![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.021.png)![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.022.png)![ref4]![ref3]

![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.023.png)![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.024.png)

![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.025.png)![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.026.png)

-:RESULT:-![ref1]![ref2]![ref5]![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.027.png)![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.028.png)![ref4]![ref3]

![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.029.png)![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.030.png)

-:LINK’S: -![ref1]![ref2]![ref3]

[https://github.com/Charvik143/VOTING_SYSTEM.git ](https://github.com/Charvik143/VOTING_SYSTEM.git)<git@github.com:Charvik143/VOTING_SYSTEM.git>



![ref4]

![ref5]

![](Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.031.png)

[ref1]: Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.001.jpeg
[ref2]: Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.002.png
[ref3]: Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.006.png
[ref4]: Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.008.png
[ref5]: Aspose.Words.7d0541a9-7332-47bd-8773-068803b554d7.009.png
